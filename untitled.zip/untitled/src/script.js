// Initialize a simple in-memory "database" for user authentication
let users = [];

// Select elements
const signupForm = document.getElementById('signupForm');
const loginForm = document.getElementById('loginForm');
const dashboard = document.getElementById('dashboard');
const userWelcome = document.getElementById('userWelcome');
const logoutBtn = document.getElementById('logoutBtn');

// Sign-up functionality
signupForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const username = document.getElementById('username').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  // Store the new user in memory
  users.push({ username, email, password });

  alert('Signup successful! Please login.');
  // Switch to login form after signup
  signupForm.style.display = 'none';
  loginForm.style.display = 'block';
});

// Login functionality
loginForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const loginUsername = document.getElementById('loginUsername').value;
  const loginPassword = document.getElementById('loginPassword').value;

  // Check if user exists and credentials match
  const user = users.find(
    (user) => user.username === loginUsername && user.password === loginPassword
  );

  if (user) {
    // Show the dashboard
    loginForm.style.display = 'none';
    dashboard.style.display = 'block';
    userWelcome.textContent = user.username;
  } else {
    alert('Invalid username or password!');
  }
});

// Logout functionality
logoutBtn.addEventListener('click', () => {
  dashboard.style.display = 'none';
  loginForm.style.display = 'block';
  document.getElementById('loginUsername').value = '';
  document.getElementById('loginPassword').value = '';
});
